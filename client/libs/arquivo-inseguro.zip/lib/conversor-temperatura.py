def converterCelsiusParaKelvin(temperatura):
    return temperatura + 273.15

def converterCelsiusParaFahrenheit(temperatura):
    return (temperatura * 9 / 5) + 32